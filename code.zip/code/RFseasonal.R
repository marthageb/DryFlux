###Look at RF model seasonal performance x site and at OzFlux sites###

library(dplyr)
library(plyr)
library(ggvis)
library(caret)


setwd("Z:/SRER/Martha/DryFlux/data")
#load the data
graphdata <- read.csv("coarseDFPred.csv")

meta <- read.csv("Z:/SRER/Martha/DryFlux/data/site_meta.csv")


graphdata$site <- substr(graphdata$sitedate, 1,6)
graphdata$month <- substr(graphdata$sitedate, 8,10)

#add veg class
graphdata <- merge(graphdata, meta[,c(2,5)], by="site")


#Split Apply Combine
out2 <- split(graphdata, graphdata$site)


######PLOT SEASONAL TREND BY SITE#######

plot_seasonal <- function(y){
  require("ggplot2")
  require("ggthemes")
  require("scales")
  require("psych")
  x <- ddply(y, .(month), summarize, coarse_se=sd(coarse_GPP, na.rm=TRUE)/sqrt(length(coarse_GPP[!is.na(coarse_GPP)])) , coarse_GPP=mean(coarse_GPP, na.rm=TRUE),
             GPP_se=sd(ObservedGPP, na.rm=TRUE)/sqrt(length(ObservedGPP[!is.na(ObservedGPP)])), GPP=mean(ObservedGPP, na.rm=TRUE),
             MODIS_se=sd(MODIS_GPP, na.rm=TRUE)/sqrt(length(MODIS_GPP[!is.na(MODIS_GPP)])), MODIS_GPP=mean(MODIS_GPP, na.rm=TRUE),
             Fluxcom_se=sd(FluxcomGPP, na.rm=TRUE)/sqrt(length(FluxcomGPP[!is.na(FluxcomGPP)])), FluxcomGPP=mean(FluxcomGPP, na.rm=TRUE))
  x$month <- factor(x$month, levels=month.abb)
  
  r_coarse <- as.character(round(cor(x$GPP, x$coarse_GPP), 3))
  r_modis <- as.character(round(cor(x$GPP, x$MODIS_GPP), 3))
  r_fluxcom <- as.character(round(cor(x$GPP, x$FluxcomGPP), 3))
  
  rmssdGPP <- as.character(round(rmssd(x$GPP), 3))
  rmssdcoarse_GPP <- as.character(round(rmssd(x$coarse_GPP), 3))
  rmssdMODIS_GPP <- as.character(round(rmssd(x$MODIS_GPP), 3))
  rmssdFluxcomGPP <- as.character(round(rmssd(x$FluxcomGPP), 3))
  
  rmsecoarse_GPP <- as.character(round(RMSE(x$coarse_GPP, x$GPP), 3))
  rmseMODIS_GPP <- as.character(round(RMSE(x$MODIS_GPP, x$GPP), 3))
  rmseFluxcomGPP <- as.character(round(RMSE(x$FluxcomGPP, x$GPP), 3))
  
  lbl1 <- paste("Observed: RMSSD =", rmssdGPP)
  lbl2 <- paste("Coarse DF: rmse =", rmsecoarse_GPP, "; r =", r_coarse, "; RMSSD =", rmssdcoarse_GPP)
  lbl4 <- paste("MODIS: rmse =", rmseMODIS_GPP, "; r =", r_modis, "; RMSSD =", rmssdMODIS_GPP)
  lbl5 <- paste("Fluxcom: rmse =", rmseFluxcomGPP, "; r =", r_fluxcom, "; RMSSD =", rmssdFluxcomGPP)
  
  lbl6 <- y$VegClass[1]
  site <- y$site[1]
  
  filename <- paste(y$site[1], "seasonal_comparison.png", sep="_")
  print(filename)
  q <- ggplot() +
    ggtitle(x$site)+
    ylim(0,7.5)+
    geom_line(data = x, aes(x = month, group=1, y = GPP, color =I("#C57B57")), size=2) +
    geom_line(data = x, aes(x = month, group=1, y = coarse_GPP, color = I("#5D576B")), size=2) +
    geom_line(data = x, aes(x = month, group=1, y = MODIS_GPP, color = I("#70AE6E")), size=2) +
    geom_line(data = x, aes(x = month, group=1, y = FluxcomGPP, color = I("#639FAB")), size=2) +
    
    geom_errorbar(data=x,aes(x=month, ymin=GPP-GPP_se,ymax=GPP+GPP_se),colour="#C57B57")+
    geom_errorbar(data=x,aes(x=month, ymin=coarse_GPP-coarse_se,ymax=coarse_GPP+coarse_se),colour="#5D576B")+
    geom_errorbar(data=x,aes(x=month, ymin=MODIS_GPP-MODIS_se,ymax=MODIS_GPP+MODIS_se),colour="#70AE6E")+
    geom_errorbar(data=x,aes(x=month, ymin=FluxcomGPP-Fluxcom_se,ymax=FluxcomGPP+Fluxcom_se),colour="#639FAB")+
    
    annotate("text", label = lbl1, parse=FALSE, x = 3.6, y = 7.5, size = 3.5, colour = "#C57B57")+
    annotate("text", label = lbl2, parse=FALSE, x = 6.4, y = 7.0, size = 3.5, colour = "#5D576B")+
    annotate("text", label = lbl4, parse=FALSE, x = 6.2, y = 6.5, size = 3.5, colour = "#70AE6E")+
    annotate("text", label = lbl5, parse=FALSE, x = 6.2, y = 6.0, size = 3.5, colour = "#639FAB")+
    
    
    annotate("text", label = lbl6, parse=FALSE, x = 11, y = 7.5, size = 4, colour = "Black")+
    ggtitle(site)+
    scale_x_discrete(limits = month.abb)+
    xlab('month')+
    ylab('GPP')+
    theme_classic()+
    theme(legend.position = c(0, 0))
  
  plot(q)
  ggsave(filename, device='png', width=10, height=10, plot=q, dpi = 300, units="cm")
}

setwd("Z:/SRER/Martha/DryFlux/plots/seasonal")
lapply(out2, plot_seasonal)
getwd()

######################################################
############SEASONAL TREND AT OZFLUX SITES############
######################################################

###SEASONAL CYCLE FOR OzFLUX SITES###
ausTest <- read.csv("aus_RFdata.csv")
names(ausTest)[names(ausTest) == "pet"] <- "PET"
ausTest <- ausTest[,-1]
ausTest <- ausTest[,c(1:16,18,17,19)]
ausTest <- ausTest[complete.cases(ausTest), ]


ausTest$DryFluxGPP <- (predict(RFmodel$finalModel, ausTest[,expvar]))

ausTest$site <- substr(ausTest$sitedate, 1,6)
ausTest$month <- substr(ausTest$sitedate, 8,10)
ausTest$month <- as.factor(ausTest$month)
#Split Apply Combine
out2 <- split(ausTest, ausTest$site)
str(out2)

plot_seasonal <- function(y){
  require("ggplot2")
  require("ggthemes")
  require("scales")
  require("psych")
  x <- ddply(y, .(month), summarize, DryFlux_se=sd(DryFluxGPP, na.rm=TRUE)/sqrt(length(DryFluxGPP[!is.na(DryFluxGPP)])) , DryFluxGPP=mean(DryFluxGPP, na.rm=TRUE),
             GPP_se=sd(GPP, na.rm=TRUE)/sqrt(length(GPP[!is.na(GPP)])), GPP=mean(GPP, na.rm=TRUE))
  x$month <- factor(x$month, levels=month.abb)
  r <- as.character(round(cor(x$GPP, x$DryFluxGPP), 3))
  rmssdGPP <- as.character(round(rmssd(x$GPP), 3))
  rmssdDF_GPP <- as.character(round(rmssd(x$DryFluxGPP), 3))
  rmseDF_GPP <- as.character(round(RMSE(x$DryFluxGPP, x$GPP), 3))
  lbl1 <- paste("Observed: RMSSD =", rmssdGPP)
  lbl2 <- paste("DryFlux: rmse =", rmseDF_GPP, "; r =", r, "; RMSSD =", rmssdDF_GPP)
  lbl4 <- y$site[1]
  filename <- paste(y$site[1], "seasonal_comparison.png", sep="_")
  print(filename)
  q <- ggplot() +
    ggtitle(x$site)+
    ylim(0,7.5)+
    geom_line(data = x, aes(x = month, group=1, y = GPP, color =I("#C57B57")), size=2) +
    geom_line(data = x, aes(x = month, group=1, y = DryFluxGPP, color = I("#5D576B")), size=2) +
    geom_errorbar(data=x,aes(x=month, ymin=GPP-GPP_se,ymax=GPP+GPP_se),colour="#C57B57")+
    geom_errorbar(data=x,aes(x=month, ymin=DryFluxGPP-DryFlux_se,ymax=DryFluxGPP+DryFlux_se),colour="#5D576B")+
    annotate("text", label = lbl1, parse=FALSE, x = 3.6, y = 7.5, size = 3.5, colour = "#C57B57")+
    annotate("text", label = lbl2, parse=FALSE, x = 6.2, y = 6, size = 3.5, colour = "#5D576B")+
    annotate("text", label = lbl4, parse=FALSE, x = 11, y = 7.5, size = 4, colour = "Black")+
    scale_x_discrete(limits = month.abb)+
    xlab('month')+
    ylab('GPP')+
    theme_classic()+
    theme(legend.position = c(0, 0))
  
  plot(q)
  ggsave(filename, device='png', width=10, height=10, plot=q, dpi = 300, units="cm")
}

setwd("Z:/SRER/Martha/DryFlux/plots/OzFlux/")
lapply(out2, plot_seasonal)
