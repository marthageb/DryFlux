###APPLY THE RF MODELS TO RASTER DATA TO PREDICT GPP ACROSS THE STUDY AREA###

library(testthat)
library(raster)
library(rgdal)
library(rangeBuilder)

################################################################################################################################################################################
####COARSE RESOLUTION DATA UPSCALING############################################################################################################################################
################################################################################################################################################################################
#first we need to get all of the raster layers to align with eachother

#for each mo/yr need to change MODIS NDVI and EVI data sets (lines 16 & 18), 'lastmo' (line 14), and 'date1' (line 15);
lastmo <- "X2014Nov"
date1 <- "X2014Dec"
r1 <- raster("Z:/SRER/Martha/DryFlux/data/MOD13C1/tifs/ndvi_2014.12.19.tif")
r1 <- r1 * 0.0001
r2 <- raster("Z:/SRER/Martha/DryFlux/data/MOD13C1/tifs/evi_2014.12.19.tif")
r2 <- r2 * 0.0001
r3 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/pet.grd")
r4 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/pre.grd")
rvap <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/vap.grd")
r6 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/tmx.grd")
r7 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/tmn.grd")
r8 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/tmp.grd")
  r9 <- subset(r4, lastmo) 
  r10 <- subset(r8, lastmo)
r11 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/spei1NEW.grd")
r12 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/spei3NEW.grd")
r13 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/spei6NEW.grd")
r14 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/spei9NEW.grd")
r15 <- stack("Z:/SRER/Martha/DryFlux/data/CRU/tifs/spei12NEW.grd")
r16 <- stack("Z:/SRER/Martha/DryFlux/data/daylength.tif")
#r17 <- stack("Z:/SRER/Martha/DryFlux/data/spatial/US_MATMAP.grd")
#if doing global analysis load MAP and MAP raster seperately
r17 <- raster("Z:/SRER/Martha/DryFlux/data/spatial/globalMAT.tif")
r17.1 <- raster("Z:/SRER/Martha/DryFlux/data/spatial/globalMAP.tif")
r18 <- raster("Z:/SRER/Martha/DryFlux/data/spatial/global_elev.tif")

#give date names to the daylength raster
  #get the dates of CRU observations
  dl_t <- read.csv("Z:/SRER/Martha/DryFlux/data/CRU/dates.csv")
  dates <- paste(dl_t$vals_year, dl_t$mo, sep=".")
names(r16) <- dates

#select the desired date with the CRU data
r3 <- subset(r3, date1) 
r4 <- subset(r4, date1) 
rvap <- subset(rvap, date1) 
r6 <- subset(r6, date1) 
r7 <- subset(r7, date1) 
r8 <- subset(r8, date1)
r11 <- subset(r11, date1) 
r12 <- subset(r12, date1) 
r13 <- subset(r13, date1)
r14 <- subset(r14, date1) 
r15 <- subset(r15, date1) 

#Calculating VPD from Tavg and vap raster
#calculate VPsat
VPsat <- 610.78 * exp((17.269*r8)/(237.3+r8))
#calculate VPD raster
r5 <- VPsat - rvap*100

dayl_date <- paste("X", substr(names(r1), 6, 10), substr(names(r1), 11, 12),sep="") # if subsetting oct, nov, or dec, change 2nd substr to 11,12; otherwise 12, 12
r16 <- subset(r16, dayl_date)

#https://gis.stackexchange.com/questions/217082/handling-multiple-extent-problem-to-create-raster-stack-in-r
files <- list()
files[[1]] <- r1
files[[2]] <- r2
files[[3]] <- r3
files[[4]] <- r4
files[[5]] <- r5
files[[6]] <- r6
files[[7]] <- r7
files[[8]] <- r8
files[[9]] <- r9
files[[10]] <- r10
files[[11]] <- r11
files[[12]] <- r12
files[[13]] <- r13
files[[14]] <- r14
files[[15]] <- r15
files[[16]] <- r16
files[[17]] <- r17
files[[18]] <- r17.1
files[[19]] <- r18

###test rasters
test <- list()

for(i in 1:length(files)){
  test[[i]] <- capture_warnings(compareRaster(r4,files[[i]], res=T, orig=T, stopiffalse=F, showwarning=T))
}
test

#reproject all rasters so that resolution and crs are matching
#use the CRU raster as the 'master'
r1_p <-projectRaster(r1, r4)
r2_p <- projectRaster(r2, r4)
#r17_p <- projectRaster(r17, r4)
#r17.1_p <- projectRaster(r17.1,r4)
#r18_p <- projectRaster(r18, r4)


#revisit the 'test' function to see if rasters 'line up'
files <- list()
files[[1]] <- r1_p
files[[2]] <- r2_p
files[[3]] <- r3
files[[4]] <- r4
files[[5]] <- r5
files[[6]] <- r6
files[[7]] <- r7
files[[8]] <- r8
files[[9]] <- r9
files[[10]] <- r10
files[[11]] <- r11
files[[12]] <- r12
files[[13]] <- r13
files[[14]] <- r14
files[[15]] <- r15
files[[16]] <- r16
files[[17]] <- r17_p
files[[18]] <- r17.1_p
files[[19]] <- r18_p

test <- list()

for(i in 1:length(files)){
  test[[i]] <- capture_warnings(compareRaster(r4,files[[i]], res=T, orig=T, stopiffalse=F, showwarning=T))
}
test

#stack all of the raster layers together
env_data <- stack(files)
env_data
names(env_data) <- c("ndvi", "evi", "pet", "precip", "vpd", "Tmax", "Tmin", "Tavg", "lastmo_precip", "lastmo_Tavg", "spei1", "spei3", "spei6", "spei9", "spei12", "daylength", "MAT", "MAP", "elev")
#writeRaster(env_data, "Z:/SRER/Martha/DryFlux/data/spatial/coarseJan2011stack.tif", format="GTiff")

#load the RFmodel
RFmodel <- readRDS("Z:/SRER/Martha/DryFlux/RFmodels/coarse_new.rds")
GPP <- predict(env_data, RFmodel)
GPP
#plot(GPP)
#text(100, 100, labels=paste(substr(date1, 2,5), substr(date1,6,8), sep=" "))

outname <- paste("Z:/SRER/Martha/DryFlux/data/spatial/RFmodels/GPPcoarse_global_", paste(substr(date1, 6,8), substr(date1,2,5), sep=""), ".tif", sep="")
print(outname)
writeRaster(GPP, outname, format="GTiff", overwrite=TRUE)

